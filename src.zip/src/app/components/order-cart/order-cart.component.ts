import { Component } from '@angular/core';

@Component({
  selector: 'app-order-cart',
  imports: [],
  templateUrl: './order-cart.component.html',
  styleUrl: './order-cart.component.scss'
})
export class OrderCartComponent {

}
