import { Component } from '@angular/core';

@Component({
  selector: 'app-app.comp',
  imports: [],
  templateUrl: './app.comp.component.html',
  styleUrl: './app.comp.component.scss'
})
export class AppCompComponent {

}
