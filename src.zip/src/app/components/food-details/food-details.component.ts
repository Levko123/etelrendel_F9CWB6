import { Component } from '@angular/core';

@Component({
  selector: 'app-food-details',
  imports: [],
  templateUrl: './food-details.component.html',
  styleUrl: './food-details.component.scss'
})
export class FoodDetailsComponent {

}
