export const environment = {
    production: false,
    firebaseConfig: {
      apiKey: 'AIzaSyAzd7VrTowtqC2-sBrI7yxqIgSXOG1qbjY',
      authDomain: 'etelrendeles-9e162.firebaseapp.com',
      projectId: 'etelrendeles-9e162',
      storageBucket: 'etelrendeles-9e162.firebasestorage.app',
      messagingSenderId: '10828358377',
      appId: '110828358377webcec61ee5c27c9f80ff8678'
    }
  };