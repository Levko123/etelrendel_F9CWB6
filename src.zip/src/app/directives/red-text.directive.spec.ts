import { RedTextDirective } from './red-text.directive';

describe('RedTextDirective', () => {
  it('should create an instance', () => {
    const directive = new RedTextDirective();
    expect(directive).toBeTruthy();
  });
});
