import { Directive } from '@angular/core';

@Directive({
  selector: '[appRedText]'
})
export class RedTextDirective {

  constructor() { }

}
